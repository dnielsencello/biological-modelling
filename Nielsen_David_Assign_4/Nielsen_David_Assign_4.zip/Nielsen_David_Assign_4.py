# -*- coding: utf-8 -*-
"""
Created on Thu Sep 29 09:08:17 2022

@author: DAVID
"""

import numpy as np
# Problem 1

#the sensor data is imported
sensor_data=np.loadtxt('mv_Sensor.csv',delimiter=',')
#looping through to adjust the values in the first and second column
sensor_data[0:,0] = [1000*sensor_data[i][0] for i in range(len(sensor_data))]
sensor_data[0:,1] = [sensor_data[i][1]/290 for i in range(len(sensor_data))]
#adjusting the console output
np.set_printoptions(precision=3,threshold=1000,edgeitems=4,suppress=True)
print(sensor_data)
Labels='milliters base ,pH level'
#the adjusted data is exported according to the specified format
np.savetxt('pH_Sensor.csv',sensor_data,fmt=['%.f','%.3f'],delimiter=',',newline='\n',header=Labels)

# Problem 2
sensor_data=np.loadtxt('Bacterial_Growth.csv',delimiter=',')
#average of the growth columns is calculated
sensor_data[0:,1]= [((sensor_data[i][1]+sensor_data[i][2]+sensor_data[i][3]+sensor_data[i][4])/4) for i in range(len(sensor_data))]
#Extra columns are deleted
for i in range(3):
    sensor_data = np.delete(sensor_data,2,1)
print(sensor_data)  
#adjusting the console output 
np.set_printoptions(precision=3,threshold=1000,edgeitems=4,suppress=True) 
#the adjusted data is exported according to the specified format
Labels = 'Hours,Growth Average'
np.savetxt('Avg_Growth.csv',sensor_data,fmt=['%.f','%.f'],delimiter=',',header=Labels)
#Problem 3

r = 0.9 #growht rate of an unrestrained prey population
s = 0.3 #growth rate of an unrestrained predator population
k = 10000 #maximum number or prey in this environment
A = 5 #maximum number of prey consumed by predator per unit time
h = 10 # number of prey needed to support 1 predator per unit time
No = 1000  #initial prey population
Po = 100 #initial predator population
yearOfDrought = 25
harePopulationAfterDrought = 2000
growthArray = []
N = No
P = Po
time = 0
# a loop calculating each finite difference of predator and prey according to each time step
for i in range(400):
    if time < yearOfDrought:
        k = 10000
    else:
        k = 2000
    growthArray.append([time,N,P])
    N += N*(r*(1-N/k)-(A*N*P)/(N**2+No**2))*0.25
    P += P*(s*(1-h*P/N))*0.25
    time += 0.25
growthArray = np.array(growthArray)
Labels = 'Years,Prey,Predators'
np.savetxt('PredatorPrey.csv',growthArray,fmt=['%.2f','%.f','%.f'],delimiter=',',header=Labels)
print(growthArray)
