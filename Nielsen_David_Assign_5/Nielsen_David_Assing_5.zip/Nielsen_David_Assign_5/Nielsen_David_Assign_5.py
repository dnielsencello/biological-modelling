import numpy as np
import matplotlib.pyplot as plt

#Problem1
#importing the PredatorPrey.csv file and loading it into an np array
PP_data=np.loadtxt('PredatorPrey.csv',delimiter=',')

#setting up to plot two sets of data onto one graph
fig, ax1 = plt.subplots()
#prey data is set to the color blue
prey = plt.scatter(PP_data[:,0],PP_data[:,1], c = 'blue')
#indicating that prey and predator will have the same x value 
ax2 = ax1.twinx()
#predator data is plotted and set to the color red
predator = ax2.scatter(PP_data[:,0],PP_data[:,2], c = 'red')
# Inclusion of title, and labeling the axis
plt.title('Predator Prey Model')
ax1.set_ylabel('Prey Population',color = 'blue')
ax1.set_xlabel('Years')
ax2.set_ylabel('Predator Population', color = 'red')
#addition of a legend
ax1.legend((prey,predator),('Prey','Predator'), loc = 'lower center')
plt.show()
#Problem2
#Each graph will be loaded from the same set of data, but will be displayed as individual graphs
Stock_data = np.loadtxt('BDX.csv', delimiter = ',')

#Scatter plot of the Open data
Open = plt.scatter(Stock_data[1:,0],Stock_data[1:,1],s = 5)
plt.title('BD Open')
plt.xlabel('Day of the Year')
plt.ylabel('Stock Price $')
#Separating the graph as an indivual graph
plt.show()

#Scatter plot of the High data
high = plt.scatter(Stock_data[1:,0],Stock_data[1:,2], s = 5)
plt.title('BD High')
plt.xlabel('Day of the Year', color = 'blue')
plt.ylabel('Stock Price $')
plt.show()

#Scatter plot of the Low data
low = plt.scatter(Stock_data[1:,0],Stock_data[1:,3], s = 5)
plt.title('BD Low')
plt.xlabel('Day of the Year')
plt.ylabel('Stock Price $')
plt.show()

#Scatter plot of the Volume
Volume = plt.scatter(Stock_data[1:,0],Stock_data[1:,6], s = 5)
plt.title('BD Volume')
plt.xlabel('Day of the Year')
plt.ylabel('Volume')
plt.show()
#Problem3

from matplotlib import cm

SWR_Data = np.loadtxt('SWR.csv', delimiter = ',')
#naming my plot
fig = plt.figure()
#making fig into a 3d Surface Plot
ax = fig.gca(projection = '3d')


x = SWR_Data[1:,0]
y = SWR_Data[0,1:]
z = SWR_Data[1:,1:]
y, x = np.meshgrid(y,x)
surf_plot = ax.plot_surface(x,y,z, cmap = cm.YlGn)
plt.xlabel('Frequency (MHz)')
plt.ylabel('Length (in.)')
fig.colorbar(surf_plot)
